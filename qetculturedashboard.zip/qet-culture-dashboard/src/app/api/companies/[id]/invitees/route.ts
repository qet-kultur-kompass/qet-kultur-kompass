import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdminSession } from "@/lib/adminGuard";
import { generateToken } from "@/lib/tokens";

const createSchema = z.object({
  name: z.string().max(200).optional().nullable(),
  email: z.string().email().max(200).optional().nullable().or(z.literal("")),
  department: z.string().max(200).optional().nullable(),
  role: z.enum(["employee", "customer", "partner"]).default("employee"),
});

// POST: legt manuell eine personalisierte Einladung an (Alternative/Ergänzung
// zum SAP-Sync, z.B. für Kunden/Geschäftspartner oder Firmen ohne SAP).
export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await requireAdminSession();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid_input", details: parsed.error.flatten() }, { status: 400 });
  }

  const invitee = await prisma.invitee.create({
    data: {
      companyId: params.id,
      name: parsed.data.name || null,
      email: parsed.data.email || null,
      department: parsed.data.department || null,
      role: parsed.data.role,
      inviteToken: generateToken(20),
      source: "manual",
    },
  });

  return NextResponse.json({ invitee }, { status: 201 });
}
