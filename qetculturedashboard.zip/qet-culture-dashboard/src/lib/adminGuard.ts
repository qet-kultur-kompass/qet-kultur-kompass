import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

/** Liefert die Admin-Session oder null. Für API-Routen, die nur Ralph/das
 * QET-Team sehen darf (Firmenliste, Dashboards, Firma anlegen). */
export async function requireAdminSession() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return null;
  return session;
}
