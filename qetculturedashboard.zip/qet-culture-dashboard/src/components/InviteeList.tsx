"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CopyField } from "./CopyField";
import { ROLE_LABELS } from "@/lib/content/i18n";

export interface InviteeRow {
  id: string;
  name: string | null;
  email: string | null;
  department: string | null;
  role: "employee" | "customer" | "partner";
  status: string;
  source: string;
  inviteToken: string;
}

export function InviteeList({
  companyId,
  invitees,
  origin,
}: {
  companyId: string;
  invitees: InviteeRow[];
  origin: string;
}) {
  const router = useRouter();
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<"employee" | "customer" | "partner">("employee");
  const [saving, setSaving] = useState(false);

  async function addInvitee(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    await fetch(`/api/companies/${companyId}/invitees`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, role }),
    });
    setSaving(false);
    setName("");
    setEmail("");
    setShowAdd(false);
    router.refresh();
  }

  return (
    <div className="rounded-2xl border border-ink/10 bg-white/60 p-6 shadow-card">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg font-semibold text-ink">
          Personalisierte Einladungen ({invitees.length})
        </h2>
        <button
          type="button"
          onClick={() => setShowAdd((s) => !s)}
          className="text-sm font-medium text-quality-600 hover:underline"
        >
          {showAdd ? "Abbrechen" : "+ Person hinzufügen"}
        </button>
      </div>

      {showAdd && (
        <form onSubmit={addInvitee} className="mt-4 flex flex-wrap items-end gap-3 rounded-xl bg-ink/[0.03] p-4">
          <label className="text-xs font-medium text-ink/60">
            Name
            <input value={name} onChange={(e) => setName(e.target.value)} className="mt-1 block rounded-lg border border-ink/15 bg-white px-3 py-1.5 text-sm" />
          </label>
          <label className="text-xs font-medium text-ink/60">
            E-Mail
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 block rounded-lg border border-ink/15 bg-white px-3 py-1.5 text-sm"
            />
          </label>
          <label className="text-xs font-medium text-ink/60">
            Rolle
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as typeof role)}
              className="mt-1 block rounded-lg border border-ink/15 bg-white px-3 py-1.5 text-sm"
            >
              {(["employee", "customer", "partner"] as const).map((r) => (
                <option key={r} value={r}>
                  {ROLE_LABELS[r].de}
                </option>
              ))}
            </select>
          </label>
          <button
            type="submit"
            disabled={saving}
            className="rounded-full bg-ink px-4 py-2 text-xs font-medium text-paper disabled:opacity-50"
          >
            {saving ? "Wird angelegt …" : "Anlegen"}
          </button>
        </form>
      )}

      {invitees.length === 0 ? (
        <p className="mt-4 text-sm text-ink/50">
          Noch keine personalisierten Einladungen. Fügen Sie manuell Personen hinzu oder richten Sie
          oben den SAP-Mitarbeiterimport ein.
        </p>
      ) : (
        <div className="mt-4 flex flex-col divide-y divide-ink/10">
          {invitees.map((inv) => (
            <div key={inv.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div className="min-w-0">
                <div className="text-sm font-medium text-ink">{inv.name || inv.email || "Ohne Namen"}</div>
                <div className="text-xs text-ink/50">
                  {ROLE_LABELS[inv.role].de}
                  {inv.department ? ` · ${inv.department}` : ""} ·{" "}
                  {inv.status === "completed" ? "beantwortet" : "ausstehend"} ·{" "}
                  {inv.source === "sap_sync" ? "aus SAP" : "manuell"}
                </div>
              </div>
              <div className="w-full max-w-xs sm:w-auto">
                <CopyField label="Persönlicher Link" value={`${origin}/invite/${inv.inviteToken}`} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
